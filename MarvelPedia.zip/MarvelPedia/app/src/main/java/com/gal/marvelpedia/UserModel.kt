package com.gal.marvelpedia

class UserModel(val userId:String, val name:String, val password:String)